# FFH4X Visual Panel — projeto Android

Painel visual demonstrativo em Android. Não altera o Free Fire e não inclui trapaças ou interação com o jogo.

## Como gerar o APK pelo celular
1. Extraia este ZIP.
2. Crie um repositório no GitHub e envie todos os arquivos mantendo as pastas.
3. Abra a aba **Actions** do repositório.
4. Selecione **Build APK** e toque em **Run workflow** (ou aguarde o build após enviar os arquivos).
5. Quando terminar, abra a execução e baixe o artefato **FFH4X-Visual-Panel-APK**.
6. Extraia o artefato para obter `app-debug.apk`.

## Requisitos
Android Studio/Gradle 8.9+ e JDK 17 para compilar localmente. O workflow do GitHub Actions faz a compilação em nuvem.
